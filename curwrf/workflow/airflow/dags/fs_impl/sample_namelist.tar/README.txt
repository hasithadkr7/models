namelist.input files order 0 through 3
C
H
NW
W
